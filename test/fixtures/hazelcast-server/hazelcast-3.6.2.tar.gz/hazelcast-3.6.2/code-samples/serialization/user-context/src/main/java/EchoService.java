class EchoService {

    void echo(String msg) {
        System.out.println(msg);
    }
}
